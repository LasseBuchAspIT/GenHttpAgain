﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenHttpAgain
{
    public class StaticString
    {
        public static string ConnectionString = "Placeholder";
    }
}
